"use client"

import type React from "react"
import { useRef, useEffect } from "react"
import { type VocabularyItem, GameStatus } from "../types"

interface GameCanvasProps {
  word: VocabularyItem | null
  posPercent: number
  status: GameStatus
}

const GameCanvas: React.FC<GameCanvasProps> = ({ word, posPercent, status }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>()

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resize = () => {
      const parent = canvas.parentElement
      if (parent) {
        canvas.width = parent.clientWidth
        canvas.height = parent.clientHeight
      }
    }

    window.addEventListener("resize", resize)
    resize()

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      if (word) {
        const x = canvas.width / 2
        const startY = 50
        const endY = canvas.height - 50
        const currentY = startY + (endY - startY) * (posPercent / 100)

        ctx.setLineDash([5, 10])
        ctx.strokeStyle = "#d1d5db"
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, canvas.height)
        ctx.stroke()
        ctx.setLineDash([])

        // Draw the falling word box
        const boxWidth = 300
        const boxHeight = 80
        const boxX = x - boxWidth / 2
        const boxY = currentY - boxHeight / 2

        ctx.shadowBlur = status === GameStatus.FALLING ? 15 : 0
        ctx.shadowColor = "rgba(0, 0, 0, 0.15)"
        ctx.shadowOffsetY = 4

        ctx.fillStyle =
          status === GameStatus.WIN
            ? "rgba(34, 197, 94, 0.95)"
            : status === GameStatus.LOSS
              ? "rgba(239, 68, 68, 0.95)"
              : "rgba(255, 255, 255, 0.98)"

        ctx.beginPath()
        ctx.roundRect(boxX, boxY, boxWidth, boxHeight, 12)
        ctx.fill()

        // Reset shadow
        ctx.shadowBlur = 0
        ctx.shadowOffsetY = 0

        ctx.strokeStyle = status === GameStatus.WIN ? "#22c55e" : status === GameStatus.LOSS ? "#ef4444" : "#f59e0b"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw Text
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"

        ctx.fillStyle = status === GameStatus.WIN || status === GameStatus.LOSS ? "#fff" : "#1f2937"
        ctx.font = "bold 24px Inter"
        ctx.fillText(word.vietnamese, x, boxY + 30)

        // Word type (Small tag)
        ctx.fillStyle = status === GameStatus.WIN || status === GameStatus.LOSS ? "rgba(255,255,255,0.8)" : "#f59e0b"
        ctx.font = "500 14px Inter"
        ctx.fillText(`(${word.type})`, x, boxY + 55)

        if (status === GameStatus.FALLING) {
          const barWidth = 4
          const barHeight = 60
          ctx.fillStyle = "#e5e7eb"
          ctx.fillRect(boxX - 20, boxY + 10, barWidth, barHeight)
          ctx.fillStyle = "#f59e0b"
          ctx.fillRect(boxX - 20, boxY + 10, barWidth, barHeight * (posPercent / 100))
        }
      }

      animationRef.current = requestAnimationFrame(render)
    }

    render()

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
      window.removeEventListener("resize", resize)
    }
  }, [word, posPercent, status])

  return <canvas ref={canvasRef} className="w-full h-full" />
}

export default GameCanvas
